package com.ldj.wow.contacts;

import android.view.View;

/**
 * Created by wowsc on 2018/7/6.
 */

public interface OnDeleteClickListener {
    public void onInfoClick(View view, int postion, int id);
}
