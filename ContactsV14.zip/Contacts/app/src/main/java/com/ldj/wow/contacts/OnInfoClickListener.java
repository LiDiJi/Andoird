package com.ldj.wow.contacts;

import android.view.View;

/**
 * Created by wowsc on 2018/7/2.
 */

public interface OnInfoClickListener {
    public void onInfoClick(View view, int postion, int offset);
}
