package com.ldj.wow.contacts;

import android.view.View;

/**
 * Created by wowsc on 2018/7/3.
 */

public interface OnCallClickListener {
    public void onCallClick(View view, int postion, String Phone_number);
}
