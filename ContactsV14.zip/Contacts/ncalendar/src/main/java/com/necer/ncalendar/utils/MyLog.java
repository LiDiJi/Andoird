package com.necer.ncalendar.utils;


import android.util.Log;


public class MyLog {
	public static void d(String msg) {
			Log.e("NECER", msg);
		}
}
