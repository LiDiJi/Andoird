package com.ldj.wow.contacts;

import android.view.View;

/**
 * Created by wowsc on 2018/7/3.
 */

public interface OnMsgClickListener {
    public void onMsgClick(View view, int postion, String phone_num);
}
