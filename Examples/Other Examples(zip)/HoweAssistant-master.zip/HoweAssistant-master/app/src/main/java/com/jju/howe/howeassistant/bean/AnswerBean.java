package com.jju.howe.howeassistant.bean;

/**
 * Created by Howe on 2016/10/23.
 */

public class AnswerBean {
    private String text;
    private String type;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}