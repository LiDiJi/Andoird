package com.jju.howe.howeassistant.bean;

/**
 * Created by Howe on 2016/10/23.
 */

public class SemanticBean {
    /**
     * name : 张三
     */

    private SlotsBean slots;

    public SlotsBean getSlots() {
        return slots;
    }

    public void setSlots(SlotsBean slots) {
        this.slots = slots;
    }


}