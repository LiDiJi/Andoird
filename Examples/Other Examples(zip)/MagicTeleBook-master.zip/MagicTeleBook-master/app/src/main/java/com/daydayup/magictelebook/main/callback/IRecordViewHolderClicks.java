package com.daydayup.magictelebook.main.callback;

/**
 * Created by Jallen on 2016/5/9.
 */
public interface IRecordViewHolderClicks {
    //单击item的监听事件
    public void onItemClick();
    //单击电话按钮的监听事件
    public void onCallBtnClick();
}
