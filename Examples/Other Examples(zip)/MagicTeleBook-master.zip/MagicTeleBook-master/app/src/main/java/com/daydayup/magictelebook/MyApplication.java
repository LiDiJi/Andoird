package com.daydayup.magictelebook;

import android.app.Application;


/**
 * Created by Jay on 16/5/23.
 */
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
