package com.daydayup.magictelebook.main.callback;

/**
 * Created by Jay on 16/5/25.
 */
public interface DefaultListener {
    void onSuccess(String msg);
    void onFailed(String msg);
}
