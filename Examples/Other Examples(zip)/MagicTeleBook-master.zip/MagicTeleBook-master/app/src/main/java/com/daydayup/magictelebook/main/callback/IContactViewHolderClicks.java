package com.daydayup.magictelebook.main.callback;

/**
 * Created by Jallen on 2016/5/10.
 */
public interface IContactViewHolderClicks {
    public void onItemClick();
}
