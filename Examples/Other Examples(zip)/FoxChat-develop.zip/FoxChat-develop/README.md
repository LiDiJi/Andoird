# FoxChat
一款好看的安卓通讯录（开发中）

## 介绍
安卓通讯录，包括通话记录、联系人、短信。
Material Design风格，android sdk >=16

### 通话记录
![Image text](https://github.com/wangyeming/FoxChat/blob/develop/demo-picture/缩略图/pic-1.png)

### 拨号盘
![Image text](https://github.com/wangyeming/FoxChat/blob/develop/demo-picture/缩略图/pic-7.png)

### 联系人
![Image text](https://github.com/wangyeming/FoxChat/blob/develop/demo-picture/缩略图/pic-3.png)

### 快速浏览联系人
![Image text](https://github.com/wangyeming/FoxChat/blob/develop/demo-picture/缩略图/pic-5.png)

### 详细联系人
![Image text](https://github.com/wangyeming/FoxChat/blob/develop/demo-picture/缩略图/pic-6.png)

### 短信
![Image text](https://github.com/wangyeming/FoxChat/blob/develop/demo-picture/缩略图/pic-4.png)

### 短信对话
![Image text](https://github.com/wangyeming/FoxChat/blob/develop/demo-picture/缩略图/pic-2.png)
