package com.wangyeming.custom.widget;

import android.app.Dialog;
import android.content.Context;

import com.wangyeming.foxchat.R;

/**
 * 底部Layout
 *
 * @author 王小明
 * @date 2015/01/18
 */
public class BottomLayout extends Dialog {

    public BottomLayout(Context context) {
        super(context,R.style.BottomLayout_Dialog);
    }


}
