package com.soubw.jcontactlib;

/**
 * Created by WX_JIN on 2016/3/10.
 */
public interface JIndexBarFilter {
	void filterList(float sideIndexY, int position, String previewText);
}
